-- MySQL dump 10.16  Distrib 10.1.9-MariaDB, for Win32 (AMD64)
--
-- Host: localhost    Database: account
-- ------------------------------------------------------
-- Server version	10.1.9-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `careers`
--

DROP TABLE IF EXISTS `careers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `careers` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `careerName` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `careers`
--

LOCK TABLES `careers` WRITE;
/*!40000 ALTER TABLE `careers` DISABLE KEYS */;
INSERT INTO `careers` VALUES (1,'mm','2016-08-13 19:11:54','2016-08-13 19:11:54');
/*!40000 ALTER TABLE `careers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cashboxes`
--

DROP TABLE IF EXISTS `cashboxes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cashboxes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cashAmount` double NOT NULL,
  `order_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cashboxes`
--

LOCK TABLES `cashboxes` WRITE;
/*!40000 ALTER TABLE `cashboxes` DISABLE KEYS */;
INSERT INTO `cashboxes` VALUES (1,3000000,100);
/*!40000 ALTER TABLE `cashboxes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categories` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `categoryName` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categories`
--

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
INSERT INTO `categories` VALUES (1,'mm','2016-08-13 19:12:57','2016-08-13 19:12:57');
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customers`
--

DROP TABLE IF EXISTS `customers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `customers` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `customerFirstName` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `customerMiddleName` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `customerLastName` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `customerMobile` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `customerPhoneJob` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `customerPhoneHome` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `customerAddress` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `customerCity` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `customerNational` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `customerDebt` double NOT NULL,
  `customerPaymentDate` date NOT NULL,
  `limit` double NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customers`
--

LOCK TABLES `customers` WRITE;
/*!40000 ALTER TABLE `customers` DISABLE KEYS */;
INSERT INTO `customers` VALUES (1,'nnnn','','lll','','','','','','',44049,'0000-00-00',2000000,'2016-08-13 19:12:28','2016-08-13 19:12:28'),(2,'bbb','','jjj','','','','','','',25911,'0000-00-00',250000,'2016-08-13 19:12:36','2016-08-13 19:12:36'),(3,'ggg','','','','','','','','',0,'0000-00-00',10000000,'2016-09-25 19:33:33','2016-09-25 19:33:33');
/*!40000 ALTER TABLE `customers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `employees`
--

DROP TABLE IF EXISTS `employees`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `employees` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `employeeFirstName` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `employeeMiddleName` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `employeeLastName` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `employeeBrithday` date NOT NULL,
  `employeeAddress` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `employeeMobile` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `employeePhoneHome` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `employeePhoneJob` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `employeeCity` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `employeeNational` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `employeeSalary` decimal(8,2) NOT NULL,
  `employeeDiscount` decimal(8,2) NOT NULL,
  `employeeFrom` date NOT NULL,
  `employeeTo` date NOT NULL,
  `career_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employees`
--

LOCK TABLES `employees` WRITE;
/*!40000 ALTER TABLE `employees` DISABLE KEYS */;
INSERT INTO `employees` VALUES (1,'سعود ','','فهد المطيري','0000-00-00','','','','','','',0.00,12.00,'0000-00-00','0000-00-00',1,'2016-08-13 19:12:11','2016-08-13 19:12:11'),(2,'لبيب','','رفعت','0000-00-00','','','','','','',0.00,0.00,'0000-00-00','0000-00-00',1,'2016-09-08 17:23:13','2016-09-08 17:23:13'),(3,'غيث','','جاسم العنزي','0000-00-00','','','','','','',0.00,0.00,'0000-00-00','0000-00-00',1,'2016-09-08 17:23:24','2016-09-08 17:23:24'),(4,'رشدي','','دولاب','0000-00-00','','','','','','',0.00,0.00,'0000-00-00','0000-00-00',1,'2016-09-08 17:23:32','2016-09-08 17:23:32'),(5,'حسام فهد','','الفوال','0000-00-00','','','','','','',0.00,0.00,'0000-00-00','0000-00-00',1,'2016-09-14 07:35:45','2016-09-14 07:35:45'),(6,'رشيد','','الماجد','0000-00-00','','','','','','',0.00,0.00,'0000-00-00','0000-00-00',1,'2016-09-14 07:35:53','2016-09-17 08:01:48');
/*!40000 ALTER TABLE `employees` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `migration` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES ('2014_10_12_000000_create_users_table',1),('2014_10_12_100000_create_password_resets_table',1),('2016_06_07_121600_create_employee',1),('2016_06_12_064711_create_career_table',1),('2016_06_13_101442_cretae_provider_table',1),('2016_06_16_075212_create_order_table',1),('2016_07_02_071655_orderdetailsTable',1),('2016_06_13_194645_create_product_table',2),('2016_06_14_081636_create_category_table',2),('2016_06_13_071228_cretae_customer_table',3);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `numberbuy`
--

DROP TABLE IF EXISTS `numberbuy`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `numberbuy` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `numberbuy`
--

LOCK TABLES `numberbuy` WRITE;
/*!40000 ALTER TABLE `numberbuy` DISABLE KEYS */;
INSERT INTO `numberbuy` VALUES (1,77),(2,78);
/*!40000 ALTER TABLE `numberbuy` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `numberrebuy`
--

DROP TABLE IF EXISTS `numberrebuy`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `numberrebuy` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `numberrebuy`
--

LOCK TABLES `numberrebuy` WRITE;
/*!40000 ALTER TABLE `numberrebuy` DISABLE KEYS */;
/*!40000 ALTER TABLE `numberrebuy` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `numberresell`
--

DROP TABLE IF EXISTS `numberresell`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `numberresell` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `numberresell`
--

LOCK TABLES `numberresell` WRITE;
/*!40000 ALTER TABLE `numberresell` DISABLE KEYS */;
/*!40000 ALTER TABLE `numberresell` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `numbersandin`
--

DROP TABLE IF EXISTS `numbersandin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `numbersandin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `numbersandin`
--

LOCK TABLES `numbersandin` WRITE;
/*!40000 ALTER TABLE `numbersandin` DISABLE KEYS */;
/*!40000 ALTER TABLE `numbersandin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `numbersandout`
--

DROP TABLE IF EXISTS `numbersandout`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `numbersandout` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `numbersandout`
--

LOCK TABLES `numbersandout` WRITE;
/*!40000 ALTER TABLE `numbersandout` DISABLE KEYS */;
INSERT INTO `numbersandout` VALUES (1,80);
/*!40000 ALTER TABLE `numbersandout` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `numbersell`
--

DROP TABLE IF EXISTS `numbersell`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `numbersell` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=107 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `numbersell`
--

LOCK TABLES `numbersell` WRITE;
/*!40000 ALTER TABLE `numbersell` DISABLE KEYS */;
INSERT INTO `numbersell` VALUES (2,69),(3,71),(4,71),(5,71),(6,73),(7,75),(8,76),(9,81),(10,82),(11,83),(12,84),(13,85),(14,86),(15,87),(16,88),(17,89),(18,90),(19,91),(20,92),(21,93),(22,94),(23,95),(24,96),(25,97),(26,98),(27,99),(28,100),(29,101),(30,102),(31,103),(32,104),(33,105),(34,106),(35,107),(36,108),(37,109),(38,110),(39,111),(40,112),(41,113),(42,114),(43,115),(44,116),(45,117),(46,118),(47,119),(48,120),(49,121),(50,122),(51,123),(52,124),(53,125),(54,126),(55,127),(56,128),(57,129),(58,130),(59,131),(60,132),(61,133),(62,134),(63,135),(64,136),(65,137),(66,138),(67,139),(68,140),(69,141),(70,142),(71,143),(72,144),(73,145),(74,146),(75,147),(76,148),(77,149),(78,150),(79,151),(80,152),(81,153),(82,154),(83,155),(84,156),(85,157),(86,158),(87,159),(88,160),(89,161),(90,162),(91,163),(92,164),(93,165),(94,166),(95,167),(96,168),(97,169),(98,170),(99,171),(100,172),(101,173),(102,174),(103,175),(104,176),(105,177),(106,178);
/*!40000 ALTER TABLE `numbersell` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `opens`
--

DROP TABLE IF EXISTS `opens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `opens` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cash` double NOT NULL,
  `bank` double NOT NULL,
  `firstGoods` double NOT NULL,
  `lastGoods` double NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `opens`
--

LOCK TABLES `opens` WRITE;
/*!40000 ALTER TABLE `opens` DISABLE KEYS */;
INSERT INTO `opens` VALUES (1,50000,500000,10000,3000);
/*!40000 ALTER TABLE `opens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `orderdetails`
--

DROP TABLE IF EXISTS `orderdetails`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `orderdetails` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `order_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `productOrderPrice` int(11) NOT NULL,
  `productOrderQuantity` int(11) NOT NULL,
  `productOrderDis` int(11) NOT NULL,
  `productOrderAllPrice` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=163 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orderdetails`
--

LOCK TABLES `orderdetails` WRITE;
/*!40000 ALTER TABLE `orderdetails` DISABLE KEYS */;
INSERT INTO `orderdetails` VALUES (1,1,1,100,12,7,1200,NULL,NULL),(2,2,1,100,4,4,384,NULL,NULL),(3,2,2,780,3,0,2340,NULL,NULL),(4,5,1,100,400,0,40000,NULL,NULL),(5,8,2,780,6,0,4680,NULL,NULL),(6,9,2,780,3,0,2340,NULL,NULL),(7,10,1,100,33,0,3300,NULL,NULL),(8,11,2,780,44,0,34320,NULL,NULL),(9,12,1,100,9,9,819,NULL,NULL),(10,69,1,100,4,0,400,NULL,NULL),(11,69,2,780,5,0,3900,NULL,NULL),(12,71,1,100,4,0,400,NULL,NULL),(13,71,2,780,4,0,3120,NULL,NULL),(14,71,3,3232,5,0,16160,NULL,NULL),(15,73,1,100,5,0,500,NULL,NULL),(16,73,2,780,5,0,3900,NULL,NULL),(17,73,4,12121,5,0,60605,NULL,NULL),(18,75,0,0,0,0,0,NULL,NULL),(19,76,1,100,4,0,400,NULL,NULL),(20,76,2,780,4,0,3120,NULL,NULL),(21,77,0,0,0,0,0,NULL,NULL),(22,78,0,0,0,0,0,NULL,NULL),(23,81,1,100,3,0,300,NULL,NULL),(24,81,2,780,3,0,2340,NULL,NULL),(25,82,0,0,0,0,0,NULL,NULL),(26,83,0,0,0,0,0,NULL,NULL),(27,84,1,100,4,3,388,NULL,NULL),(28,85,1,100,3,0,300,NULL,NULL),(29,86,1,100,3,0,300,NULL,NULL),(30,87,0,0,0,0,0,NULL,NULL),(31,88,0,0,0,0,0,NULL,NULL),(32,89,0,0,0,0,0,NULL,NULL),(33,90,0,0,0,0,0,NULL,NULL),(34,91,1,100,44,0,4400,NULL,NULL),(35,92,1,100,44,0,4400,NULL,NULL),(36,93,1,100,44,0,4400,NULL,NULL),(37,94,1,100,4,0,400,NULL,NULL),(38,95,4,12121,4,0,48484,NULL,NULL),(39,96,2,780,7,6,5132,NULL,NULL),(40,97,2,780,7,6,5132,NULL,NULL),(41,98,2,780,5,0,3900,NULL,NULL),(42,99,2,780,5,4,3744,NULL,NULL),(43,100,1,100,4,3,388,NULL,NULL),(44,101,1,100,8,0,800,NULL,NULL),(45,102,1,100,5,0,500,NULL,NULL),(46,102,3,3232,5,0,16160,NULL,NULL),(47,103,1,100,6,0,600,NULL,NULL),(48,104,0,0,0,0,0,NULL,NULL),(49,105,0,0,0,0,0,NULL,NULL),(50,106,0,0,0,0,0,NULL,NULL),(51,107,1,100,5,33,335,NULL,NULL),(52,108,2,780,5,55,1755,NULL,NULL),(53,109,1,100,512,12,45056,NULL,NULL),(54,110,1,100,5,11,445,NULL,NULL),(55,110,2,780,4,10,2808,NULL,NULL),(56,110,4,12121,4,12,42666,NULL,NULL),(57,111,1,100,5,0,500,NULL,NULL),(58,111,0,0,0,0,0,NULL,NULL),(59,112,1,100,3,12,264,NULL,NULL),(60,112,2,780,0,0,0,NULL,NULL),(61,113,2,780,4,12,2746,NULL,NULL),(62,113,0,0,0,0,0,NULL,NULL),(63,114,2,780,4,12,2746,NULL,NULL),(64,115,1,100,4,10,360,NULL,NULL),(65,115,2,780,4,12,2746,NULL,NULL),(66,116,1,100,5,4,480,NULL,NULL),(67,116,3,3232,4,0,12928,NULL,NULL),(68,116,0,0,0,0,0,NULL,NULL),(69,116,0,0,0,0,0,NULL,NULL),(70,116,0,0,0,0,0,NULL,NULL),(71,116,0,0,0,0,0,NULL,NULL),(72,116,0,0,0,0,0,NULL,NULL),(73,116,0,0,0,0,0,NULL,NULL),(74,116,0,0,0,0,0,NULL,NULL),(75,116,0,0,0,0,0,NULL,NULL),(76,117,2,780,4,4,2995,NULL,NULL),(77,117,1,100,4,0,400,NULL,NULL),(78,118,1,100,3,3,291,NULL,NULL),(79,118,2,780,2,3,1513,NULL,NULL),(80,118,3,3232,3,0,9696,NULL,NULL),(81,118,0,0,0,0,0,NULL,NULL),(82,119,1,100,5,12,440,NULL,NULL),(83,119,2,780,5,0,3900,NULL,NULL),(84,119,0,0,0,0,0,NULL,NULL),(85,119,0,0,0,0,0,NULL,NULL),(86,120,1,100,5,1,495,NULL,NULL),(87,120,3,3232,3,12,8532,NULL,NULL),(88,121,2,780,5,0,3900,NULL,NULL),(89,121,3,3232,4,12,11377,NULL,NULL),(90,122,1,100,5,12,440,NULL,NULL),(91,122,2,780,0,0,0,NULL,NULL),(92,123,1,100,5,12,440,NULL,NULL),(93,123,0,0,0,0,0,NULL,NULL),(94,124,1,100,4,12,352,NULL,NULL),(95,124,2,780,5,12,3432,NULL,NULL),(96,125,2,780,4,1,3089,NULL,NULL),(97,125,0,0,0,12,0,NULL,NULL),(98,126,3,3232,4,0,12928,NULL,NULL),(99,126,5,2121,31,12,57861,NULL,NULL),(100,127,1,100,4,1,396,NULL,NULL),(101,127,1,100,4,12,352,NULL,NULL),(102,128,0,0,0,0,0,NULL,NULL),(103,129,0,0,0,0,0,NULL,NULL),(104,130,0,0,0,0,0,NULL,NULL),(105,131,2,780,4,12,2746,NULL,NULL),(106,132,1,100,5,12,440,NULL,NULL),(107,133,2,780,4,12,2746,NULL,NULL),(108,134,1,100,5,12,440,NULL,NULL),(109,135,1,100,7,12,616,NULL,NULL),(110,136,1,100,31,12,2728,NULL,NULL),(111,137,1,100,31,12,2728,NULL,NULL),(112,138,1,100,4,12,352,NULL,NULL),(113,139,1,100,4,12,352,NULL,NULL),(114,140,1,100,3,12,264,NULL,NULL),(115,141,1,100,5,0,500,NULL,NULL),(116,141,2,780,3,12,2059,NULL,NULL),(117,142,2,780,4,0,3120,NULL,NULL),(118,143,0,0,0,0,0,NULL,NULL),(119,144,2,780,5,0,3900,NULL,NULL),(120,145,1,100,3,12,264,NULL,NULL),(121,146,0,0,0,0,0,NULL,NULL),(122,147,1,100,4,4,384,NULL,NULL),(123,147,3,3232,4,12,11377,NULL,NULL),(124,148,0,0,0,0,0,NULL,NULL),(125,149,0,0,0,0,0,NULL,NULL),(126,150,1,100,5,12,440,NULL,NULL),(127,151,1,100,5,12,440,NULL,NULL),(128,152,1,100,52,2,5096,NULL,NULL),(129,153,2,780,7,7,5078,NULL,NULL),(130,154,2,780,7,7,5078,NULL,NULL),(131,155,2,780,7,7,5078,NULL,NULL),(132,156,2,780,7,7,5078,NULL,NULL),(133,157,2,780,7,7,5078,NULL,NULL),(134,158,2,780,7,7,5078,NULL,NULL),(135,159,1,100,5,4,480,NULL,NULL),(136,160,2,780,4,4,2995,NULL,NULL),(137,161,2,780,6,4,4493,NULL,NULL),(138,162,2,780,6,4,4493,NULL,NULL),(139,163,2,780,6,4,4493,NULL,NULL),(140,164,2,780,8,2,6115,NULL,NULL),(141,165,2,780,8,2,6115,NULL,NULL),(142,165,2,780,7,3,5296,NULL,NULL),(143,165,1,100,66,6,6204,NULL,NULL),(144,165,0,0,0,0,0,NULL,NULL),(145,166,1,100,5,5,475,NULL,NULL),(146,166,2,780,6,3,4540,NULL,NULL),(147,167,1,100,5,5,475,NULL,NULL),(148,167,2,780,6,3,4540,NULL,NULL),(149,168,1,100,5,4,480,NULL,NULL),(150,168,2,780,5,2,3822,NULL,NULL),(151,169,2,780,5,5,3705,NULL,NULL),(152,169,2,780,6,4,4493,NULL,NULL),(153,170,1,100,5,5,475,NULL,NULL),(154,171,1,100,4,5,380,NULL,NULL),(155,172,3,3232,5,5,15352,NULL,NULL),(156,176,1,100,8,9,800,NULL,NULL),(157,176,2,780,9,11,7020,NULL,NULL),(158,177,1,100,1,1,100,NULL,NULL),(159,177,2,780,1,9,780,NULL,NULL),(160,178,1,100,5,11,445,NULL,NULL),(161,178,2,780,1,1,772,NULL,NULL),(162,178,1,100,1,7,93,NULL,NULL);
/*!40000 ALTER TABLE `orderdetails` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `orders`
--

DROP TABLE IF EXISTS `orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `orders` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `orderType` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `orderDate` date NOT NULL,
  `orderPaymentType` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `orderBankName` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `typeFromto` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `fromto` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `orderCheckNO` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `orderDueDate` date NOT NULL,
  `employee_id` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `employeeName` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
  `customer_id` int(11) NOT NULL,
  `provider_id` int(11) NOT NULL,
  `getMoney` double NOT NULL,
  `backMoney` double NOT NULL,
  `orderPayment` double NOT NULL,
  `orderOutPayment` double NOT NULL,
  `orderNote` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `month` varchar(3) COLLATE utf8_unicode_ci NOT NULL,
  `numberbill` int(10) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=179 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orders`
--

LOCK TABLES `orders` WRITE;
/*!40000 ALTER TABLE `orders` DISABLE KEYS */;
INSERT INTO `orders` VALUES (73,'sell','2016-09-26','اختر','','','','','0000-00-00','1','',1,0,600,64405,65005,0,'','09',0,NULL,NULL),(74,'sell','0000-00-00','اختر','','','','','0000-00-00','1','',1,0,0,0,0,0,'','09',0,NULL,NULL),(75,'sell','0000-00-00','اختر','','','','','0000-00-00','1','',1,0,0,0,0,0,'','09',0,NULL,NULL),(76,'sell','0000-00-00','اختر','','','','','0000-00-00','1','',1,0,44,3476,3520,0,'','09',0,NULL,NULL),(77,'buy','0000-00-00','اختر','','','','','0000-00-00','1','',0,1,0,0,0,0,'','',0,NULL,NULL),(78,'buy','0000-00-00','اختر','','','','','0000-00-00','1','',0,1,0,0,0,0,'','',0,NULL,NULL),(79,'sandout','2016-09-15','نوع الدفع','','','','','0000-00-00','1','',0,1,0,0,0,50000,'','',0,NULL,NULL),(80,'sandout','2016-09-27','نوع الدفع','','','','','0000-00-00','1','',1,1,0,0,0,5000,'','',0,NULL,NULL),(81,'sell','2016-09-27','cash','','','','','2016-09-27','1','',2,0,1000,1640,2640,0,'','09',0,NULL,NULL),(82,'sell','0000-00-00','اختر','','','','','0000-00-00','1','',1,0,0,0,0,0,'','09',0,NULL,NULL),(83,'sell','0000-00-00','اختر','','','','','0000-00-00','1','',1,0,0,0,0,0,'','09',0,NULL,NULL),(84,'sell','0000-00-00','اختر','','','','','0000-00-00','1','',1,0,0,0,0,0,'','09',0,NULL,NULL),(85,'sell','0000-00-00','اختر','','','','','0000-00-00','1','',1,0,2400,240,2640,0,'','09',0,NULL,NULL),(86,'sell','0000-00-00','اختر','','','','','0000-00-00','1','',1,0,2400,240,2640,0,'','09',0,NULL,NULL),(87,'sell','0000-00-00','اختر','','','','','0000-00-00','1','',1,0,0,0,0,0,'','09',0,NULL,NULL),(88,'sell','0000-00-00','اختر','','','','','0000-00-00','1','',1,0,0,0,0,0,'','09',0,NULL,NULL),(89,'sell','0000-00-00','اختر','','','','','0000-00-00','1','',1,0,0,0,0,0,'','09',0,NULL,NULL),(90,'sell','0000-00-00','اختر','','','','','0000-00-00','1','',1,0,0,0,0,0,'','09',0,NULL,NULL),(91,'sell','0000-00-00','اختر','','','','','0000-00-00','1','',1,0,0,0,0,0,'','09',0,NULL,NULL),(92,'sell','0000-00-00','اختر','','','','','0000-00-00','1','',1,0,0,0,0,0,'','09',0,NULL,NULL),(93,'sell','0000-00-00','اختر','','','','','0000-00-00','1','',1,0,0,0,0,0,'','09',0,NULL,NULL),(94,'sell','0000-00-00','اختر','','','','','0000-00-00','1','',1,0,0,0,0,0,'','09',0,NULL,NULL),(95,'sell','0000-00-00','اختر','','','','','0000-00-00','1','',1,0,0,0,0,0,'','09',0,NULL,NULL),(96,'sell','0000-00-00','اختر','','','','','0000-00-00','1','',1,0,0,0,0,0,'','09',0,NULL,NULL),(97,'sell','0000-00-00','اختر','','','','','0000-00-00','1','',1,0,0,0,0,0,'','09',0,NULL,NULL),(98,'sell','0000-00-00','اختر','','','','','0000-00-00','1','',1,0,0,0,0,0,'','09',0,NULL,NULL),(99,'sell','0000-00-00','اختر','','','','','0000-00-00','1','',1,0,0,0,0,0,'','09',0,NULL,NULL),(100,'sell','0000-00-00','اختر','','','','','0000-00-00','1','',1,0,0,0,0,0,'','09',0,NULL,NULL),(101,'sell','0000-00-00','اختر','','','','','0000-00-00','1','',1,0,0,0,0,0,'','09',0,NULL,NULL),(102,'sell','0000-00-00','اختر','','','','','0000-00-00','1','',1,0,0,0,0,0,'','09',0,NULL,NULL),(103,'sell','0000-00-00','اختر','','','','','0000-00-00','1','',1,0,0,0,0,0,'','09',0,NULL,NULL),(104,'sell','0000-00-00','اختر','','','','','0000-00-00','','mazen',1,0,0,0,0,0,'','09',0,NULL,NULL),(105,'sell','0000-00-00','اختر','','','','','0000-00-00','','mazen',1,0,0,0,0,0,'','09',0,NULL,NULL),(106,'sell','0000-00-00','اختر','','','','','0000-00-00','','mazen',1,0,0,0,0,0,'','09',0,NULL,NULL),(107,'sell','0000-00-00','اختر','','','','','0000-00-00','','mazen',1,0,0,0,0,0,'','09',0,NULL,NULL),(108,'sell','0000-00-00','اختر','','','','','0000-00-00','','mazen',1,0,0,0,0,0,'','09',0,NULL,NULL),(109,'sell','0000-00-00','اختر','','','','','0000-00-00','','mazen',1,0,0,0,0,0,'','09',0,NULL,NULL),(110,'sell','0000-00-00','اختر','','','','','0000-00-00','','mazen',1,0,0,0,0,0,'','09',0,NULL,NULL),(111,'sell','0000-00-00','اختر','','','','','0000-00-00','','mazen',1,0,0,0,0,0,'','09',0,NULL,NULL),(112,'sell','0000-00-00','اختر','','','','','0000-00-00','','mazen',1,0,0,0,0,0,'','09',0,NULL,NULL),(113,'sell','0000-00-00','اختر','','','','','0000-00-00','','mazen',1,0,0,0,0,0,'','09',0,NULL,NULL),(114,'sell','0000-00-00','اختر','','','','','0000-00-00','','mazen',1,0,0,0,0,0,'','09',0,NULL,NULL),(115,'sell','0000-00-00','اختر','','','','','0000-00-00','','mazen',1,0,0,0,0,0,'','09',0,NULL,NULL),(116,'sell','0000-00-00','اختر','','','','','0000-00-00','','mazen',1,0,0,0,0,0,'','09',0,NULL,NULL),(117,'sell','0000-00-00','اختر','','','','','0000-00-00','','mazen',1,0,0,0,0,0,'','09',0,NULL,NULL),(118,'sell','0000-00-00','اختر','','','','','0000-00-00','','mazen',1,0,0,0,0,0,'','09',0,NULL,NULL),(119,'sell','0000-00-00','اختر','','','','','0000-00-00','','mazen',1,0,0,0,0,0,'','09',0,NULL,NULL),(120,'sell','0000-00-00','اختر','','','','','0000-00-00','','mazen',1,0,0,0,0,0,'','09',0,NULL,NULL),(121,'sell','0000-00-00','اختر','','','','','0000-00-00','','mazen',1,0,0,0,0,0,'','09',0,NULL,NULL),(122,'sell','0000-00-00','اختر','','','','','0000-00-00','','mazen',1,0,0,0,0,0,'','09',0,NULL,NULL),(123,'sell','0000-00-00','اختر','','','','','0000-00-00','','mazen',1,0,0,0,0,0,'','09',0,NULL,NULL),(124,'sell','0000-00-00','اختر','','','','','0000-00-00','','mazen',1,0,0,0,0,0,'','09',0,NULL,NULL),(125,'sell','0000-00-00','اختر','','','','','0000-00-00','','mazen',1,0,0,0,0,0,'','09',0,NULL,NULL),(126,'sell','0000-00-00','اختر','','','','','0000-00-00','','mazen',1,0,0,0,0,0,'','09',0,NULL,NULL),(127,'sell','0000-00-00','اختر','','','','','0000-00-00','','mazen',1,0,0,0,0,0,'','09',0,NULL,NULL),(128,'sell','0000-00-00','اختر','','','','','0000-00-00','','mazen',1,0,0,0,0,0,'','09',0,NULL,NULL),(129,'sell','0000-00-00','اختر','','','','','0000-00-00','','mazen',1,0,0,0,0,0,'','09',0,NULL,NULL),(130,'sell','0000-00-00','اختر','','','','','0000-00-00','','mazen',1,0,0,0,0,0,'','09',0,NULL,NULL),(131,'sell','0000-00-00','اختر','','','','','0000-00-00','','mazen',1,0,0,0,0,0,'','09',0,NULL,NULL),(132,'sell','0000-00-00','اختر','','','','','0000-00-00','','mazen',1,0,0,0,0,0,'','09',0,NULL,NULL),(133,'sell','0000-00-00','اختر','','','','','0000-00-00','','mazen',1,0,0,0,0,0,'','09',0,NULL,NULL),(134,'sell','0000-00-00','اختر','','','','','0000-00-00','','mazen',1,0,0,0,0,0,'','09',0,NULL,NULL),(135,'sell','0000-00-00','اختر','','','','','0000-00-00','','mazen',1,0,0,0,0,0,'','09',0,NULL,NULL),(136,'sell','0000-00-00','اختر','','','','','0000-00-00','','mazen',1,0,0,0,0,0,'','09',0,NULL,NULL),(137,'sell','0000-00-00','اختر','','','','','0000-00-00','','mazen',1,0,0,0,0,0,'','09',0,NULL,NULL),(138,'sell','0000-00-00','اختر','','','','','0000-00-00','','mazen',1,0,0,0,0,0,'','09',0,NULL,NULL),(139,'sell','0000-00-00','اختر','','','','','0000-00-00','','mazen',1,0,0,0,0,0,'','09',0,NULL,NULL),(140,'sell','0000-00-00','اختر','','','','','0000-00-00','','mazen',1,0,0,0,0,0,'','09',0,NULL,NULL),(141,'sell','0000-00-00','اختر','','','','','0000-00-00','','mazen',1,0,0,0,0,0,'','09',0,NULL,NULL),(142,'sell','0000-00-00','اختر','','','','','0000-00-00','','mazen',1,0,0,0,0,0,'','09',0,NULL,NULL),(143,'sell','0000-00-00','اختر','','','','','0000-00-00','','mazen',1,0,0,0,0,0,'','09',0,NULL,NULL),(144,'sell','0000-00-00','اختر','','','','','0000-00-00','','mazen',1,0,0,0,0,0,'','09',0,NULL,NULL),(145,'sell','0000-00-00','اختر','','','','','0000-00-00','','mazen',1,0,0,0,0,0,'','09',0,NULL,NULL),(146,'sell','0000-00-00','اختر','','','','','0000-00-00','','mazen',1,0,0,0,0,0,'','09',0,NULL,NULL),(147,'sell','0000-00-00','اختر','','','','','0000-00-00','','mazen',1,0,0,0,0,0,'','09',0,NULL,NULL),(148,'sell','0000-00-00','اختر','','','','','0000-00-00','','mazen',1,0,0,0,0,0,'','09',0,NULL,NULL),(149,'sell','0000-00-00','اختر','','','','','0000-00-00','','mazen',1,0,0,0,0,0,'','09',0,NULL,NULL),(150,'sell','0000-00-00','اختر','','','','','0000-00-00','','mazen',1,0,0,0,0,0,'','09',0,NULL,NULL),(151,'sell','0000-00-00','اختر','','','','','0000-00-00','','mazen',1,0,0,0,0,0,'','09',0,NULL,NULL),(152,'sell','0000-00-00','اختر','','','','','0000-00-00','','mazen',1,0,0,0,0,0,'','09',0,NULL,NULL),(153,'sell','0000-00-00','اختر','','','','','0000-00-00','','mazen',1,0,0,0,0,0,'','09',0,NULL,NULL),(154,'sell','0000-00-00','اختر','','','','','0000-00-00','','mazen',1,0,0,0,0,0,'','09',0,NULL,NULL),(155,'sell','0000-00-00','اختر','','','','','0000-00-00','','mazen',1,0,0,0,0,0,'','09',0,NULL,NULL),(156,'sell','0000-00-00','اختر','','','','','0000-00-00','','mazen',1,0,0,0,0,0,'','09',0,NULL,NULL),(157,'sell','0000-00-00','اختر','','','','','0000-00-00','','mazen',1,0,0,0,0,0,'','09',0,NULL,NULL),(158,'sell','0000-00-00','اختر','','','','','0000-00-00','','mazen',1,0,0,0,0,0,'','09',0,NULL,NULL),(159,'sell','0000-00-00','اختر','','','','','0000-00-00','','mazen',1,0,0,0,0,0,'','09',0,NULL,NULL),(160,'sell','0000-00-00','اختر','','','','','0000-00-00','','mazen',1,0,0,0,0,0,'','09',0,NULL,NULL),(161,'sell','0000-00-00','اختر','','','','','0000-00-00','','mazen',1,0,0,0,0,0,'','09',0,NULL,NULL),(162,'sell','0000-00-00','اختر','','','','','0000-00-00','','mazen',1,0,0,0,0,0,'','09',0,NULL,NULL),(163,'sell','0000-00-00','اختر','','','','','0000-00-00','','mazen',1,0,0,0,0,0,'','09',0,NULL,NULL),(164,'sell','0000-00-00','اختر','','','','','0000-00-00','','mazen',1,0,0,0,0,0,'','09',0,NULL,NULL),(165,'sell','0000-00-00','اختر','','','','','0000-00-00','','mazen',1,0,0,0,0,0,'','09',0,NULL,NULL),(166,'sell','0000-00-00','اختر','','','','','0000-00-00','','mazen',1,0,0,0,0,0,'','09',0,NULL,NULL),(167,'sell','0000-00-00','اختر','','','','','0000-00-00','','mazen',1,0,0,0,0,0,'','09',0,NULL,NULL),(168,'sell','0000-00-00','اختر','','','','','0000-00-00','','mazen',1,0,0,0,0,0,'','09',0,NULL,NULL),(169,'sell','0000-00-00','اختر','','','','','0000-00-00','','mazen',1,0,0,0,0,0,'','09',0,NULL,NULL),(170,'sell','0000-00-00','اختر','','','','','0000-00-00','','mazen',1,0,0,0,0,0,'','09',0,NULL,NULL),(171,'sell','0000-00-00','اختر','','','','','0000-00-00','','mazen',1,0,0,0,0,0,'','09',0,NULL,NULL),(172,'sell','0000-00-00','اختر','','','','','0000-00-00','','mazen',1,0,0,0,0,0,'','09',0,NULL,NULL),(173,'sell','0000-00-00','اختر','','','','','0000-00-00','','mazen',1,0,0,0,0,0,'','09',0,NULL,NULL),(174,'sell','0000-00-00','اختر','','','','','0000-00-00','','mazen',1,0,0,0,0,0,'','09',0,NULL,NULL),(175,'sell','0000-00-00','اختر','','','','','0000-00-00','','mazen',1,0,0,0,0,0,'','09',0,NULL,NULL),(176,'sell','0000-00-00','اختر','','','','','0000-00-00','','mazen',1,0,0,0,0,0,'','09',0,NULL,NULL),(177,'sell','0000-00-00','اختر','','','','','0000-00-00','','mazen',1,0,0,0,0,0,'','09',0,NULL,NULL),(178,'sell','0000-00-00','اختر','','','','','0000-00-00','','mazen',1,0,0,0,0,0,'','09',0,NULL,NULL);
/*!40000 ALTER TABLE `orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_resets`
--

DROP TABLE IF EXISTS `password_resets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  KEY `password_resets_email_index` (`email`),
  KEY `password_resets_token_index` (`token`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_resets`
--

LOCK TABLES `password_resets` WRITE;
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `products`
--

DROP TABLE IF EXISTS `products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `products` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `productCode` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `productName` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `productDescription` text COLLATE utf8_unicode_ci NOT NULL,
  `productNetPrice` double NOT NULL,
  `productQuntity` int(11) NOT NULL,
  `allQuantity` double NOT NULL,
  `productUnit` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `productSellPrice` double NOT NULL,
  `productTotalPrice` double NOT NULL,
  `category_id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `products`
--

LOCK TABLES `products` WRITE;
/*!40000 ALTER TABLE `products` DISABLE KEYS */;
INSERT INTO `products` VALUES (1,'22211','oil','',100,49780,99560,'',0,0,1,0,'2016-08-13 19:13:24','2016-09-17 08:18:32'),(2,'111','zahra','',780,80032,2000000,'',0,0,1,0,'2016-08-13 19:13:49','2016-08-13 19:13:49'),(3,'323232','هميرغر','ثصثص',3232,10000,15000,'32',0,30000,1,0,'2016-09-04 05:42:35','2016-09-04 05:42:35'),(4,'34343','rerere','qwqw',12121,121212,150000,'2121',0,2121,1,0,'2016-09-04 05:44:12','2016-09-04 05:44:12'),(5,'3232','bbb','2121',2121,10000,12000,'3232',0,2121,1,0,'2016-09-04 05:44:35','2016-09-04 05:44:35'),(6,'3232','2121','2121',2121,2121,2500,'212',0,2121,1,0,'2016-09-04 05:44:51','2016-09-04 05:44:51');
/*!40000 ALTER TABLE `products` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `providers`
--

DROP TABLE IF EXISTS `providers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `providers` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `providerFirstName` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `providerMiddleName` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `providerLastName` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `providerCompany` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `providerMobile` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `providerPhoneJob` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `providerPhoneHome` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `providerAddress` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `providerCity` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `providerNational` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `providerCreditor` double NOT NULL,
  `providerPaymentDate` date NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `providers`
--

LOCK TABLES `providers` WRITE;
/*!40000 ALTER TABLE `providers` DISABLE KEYS */;
INSERT INTO `providers` VALUES (1,'jjj','','','','','','','','','',0,'0000-00-00','2016-08-19 20:54:38','2016-08-19 20:54:38');
/*!40000 ALTER TABLE `providers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `userDisc` int(11) NOT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `admin` tinyint(4) NOT NULL,
  `remember_token` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'mazen','mazen@mazen.com',12,'$2y$10$2c4Ej0bsB5o0SWrY0xK4oerxdjk9/oMDr7fBWDbKTf7R/ZHKYtkNu',1,'4WHsjCSescC5qSH26zf3s6HJFUVUcGDACcTf8uhmc3iXcfbsWnwV8bZp4Ohv','2016-08-13 18:14:11','2016-09-30 12:41:59'),(2,'Lara','lara@lara.com',20,'$2y$10$nI7oEE7e1fpuqAdZIxZw2ezeNEFil6vRncC1ieb.ehZUZGgHhRt16',0,'A7kbUGhAgX0ifHcCreZGSlKa5aWhyNLyYDCFYfgBDJzgcPhPuzvFVG4qLeMv','2016-09-14 12:23:35','2016-09-30 12:41:11'),(3,'test7','test@test.mmm8',0,'$2y$10$uEKNcW0KwnCzQokGfTQVvOzDDLGymSCfk245MkQpq0BELJcr3IL0a',1,'eSpVdAkEJvCzKJ5e6E3uAl67a9BoNwlTtdWSfrnL7nzn1n3sRI0ePlDjrNXp','2016-09-15 12:06:35','2016-09-16 17:36:37'),(4,'sham','sham@sham.com',0,'$2y$10$S1ShJh/wh75dHyckR0RJ7eBZNz4v50WIV..gsVY65VE2NFAHN5m9S',2,NULL,'2016-09-15 17:44:41','2016-09-17 08:21:13'),(5,'Hanan','hanan@hanan.com',0,'$2y$10$9X93s3/5IwGAuo3VlvbsZ.5MEYNXqz4Qe6JtSnBomf481zrj0D2WG',0,NULL,'2016-09-24 15:50:02','2016-09-24 15:50:02'),(6,'test','test@4.n',0,'$2y$10$ZCLDo7iLCJn20TSjh8m7kOioRHdTWOLCgHM1jphnXfbOEzgw7bgbK',0,NULL,'2016-09-24 16:01:34','2016-09-24 16:01:34');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-10-03 11:30:01
