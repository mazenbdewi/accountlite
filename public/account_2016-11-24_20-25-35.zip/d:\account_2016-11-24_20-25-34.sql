-- MySQL dump 10.16  Distrib 10.1.9-MariaDB, for Win32 (AMD64)
--
-- Host: localhost    Database: account
-- ------------------------------------------------------
-- Server version	10.1.9-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `careers`
--

DROP TABLE IF EXISTS `careers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `careers` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `careerName` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `careers`
--

LOCK TABLES `careers` WRITE;
/*!40000 ALTER TABLE `careers` DISABLE KEYS */;
INSERT INTO `careers` VALUES (1,'mm','2016-08-13 19:11:54','2016-08-13 19:11:54');
/*!40000 ALTER TABLE `careers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cars`
--

DROP TABLE IF EXISTS `cars`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cars` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `carNumber` varchar(25) NOT NULL,
  `carName` varchar(30) NOT NULL,
  `carModel` varchar(30) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `carNumber` (`carNumber`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cars`
--

LOCK TABLES `cars` WRITE;
/*!40000 ALTER TABLE `cars` DISABLE KEYS */;
INSERT INTO `cars` VALUES (1,'666','666','4343'),(2,'1111','1111','222'),(3,'2222','1111','22222'),(4,'mmm','mmmm','mmm'),(5,'wwww','www','wwww');
/*!40000 ALTER TABLE `cars` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cashboxes`
--

DROP TABLE IF EXISTS `cashboxes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cashboxes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cashAmount` double NOT NULL,
  `order_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cashboxes`
--

LOCK TABLES `cashboxes` WRITE;
/*!40000 ALTER TABLE `cashboxes` DISABLE KEYS */;
INSERT INTO `cashboxes` VALUES (1,3000000,100);
/*!40000 ALTER TABLE `cashboxes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categories` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `categoryName` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categories`
--

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
INSERT INTO `categories` VALUES (1,'mm','2016-08-13 19:12:57','2016-08-13 19:12:57');
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customers`
--

DROP TABLE IF EXISTS `customers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `customers` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `customerFirstName` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `customerMiddleName` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `customerLastName` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `customerMobile` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `customerPhoneJob` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `customerPhoneHome` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `customerAddress` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `customerCity` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `customerNational` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `customerDebt` double NOT NULL,
  `customerPaymentDate` date NOT NULL,
  `limit` double NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customers`
--

LOCK TABLES `customers` WRITE;
/*!40000 ALTER TABLE `customers` DISABLE KEYS */;
INSERT INTO `customers` VALUES (2,'رفعت ','','نجار','43434343','434343','434343','434343','44343','434343',21977,'0000-00-00',250000,'2016-08-13 19:12:36','2016-11-05 16:18:32'),(3,'نادر ','','وفائي','434343','43434','4343','434343','434343','43434343',71829476,'0000-00-00',10000000,'2016-09-25 19:33:33','2016-11-05 16:20:05');
/*!40000 ALTER TABLE `customers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `employees`
--

DROP TABLE IF EXISTS `employees`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `employees` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `employeeFirstName` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `employeeMiddleName` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `employeeLastName` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `employeeBrithday` date NOT NULL,
  `employeeAddress` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `employeeMobile` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `employeePhoneHome` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `employeePhoneJob` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `employeeCity` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `employeeNational` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `employeeSalary` decimal(8,2) NOT NULL,
  `employeeDiscount` decimal(8,2) NOT NULL,
  `employeeFrom` date NOT NULL,
  `employeeTo` date NOT NULL,
  `career_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employees`
--

LOCK TABLES `employees` WRITE;
/*!40000 ALTER TABLE `employees` DISABLE KEYS */;
INSERT INTO `employees` VALUES (2,'لبيب','','رفعت','2016-10-29','ghvjfhghgf','87886775','8867676','','dsds','dsds',6000.00,0.00,'2016-10-29','0000-00-00',1,'2016-09-08 17:23:13','2016-11-05 14:39:59'),(3,'غيث','','جاسم العنزي','2016-11-05','dsdsds','34434343','434343','434343','dsds','sdsds',4000.00,0.00,'2016-11-05','0000-00-00',1,'2016-09-08 17:23:24','2016-11-05 14:39:46'),(4,'رشدي','','دولاب','2016-11-05','fdfdfdfd','3232','32323','323232','','',3000.00,0.00,'2016-11-05','0000-00-00',1,'2016-09-08 17:23:32','2016-11-05 14:40:33'),(5,'حسام فهد','','الفوال','2016-11-05','jkjlkjllkj','6566464','534343','767676','','',4600.00,0.00,'2016-11-05','0000-00-00',1,'2016-09-14 07:35:45','2016-11-05 14:41:10'),(6,'رشيد','','الماجد','2016-11-05','mnmnm','767676','6767575','6646546','','',7999.00,0.00,'2016-11-05','0000-00-00',1,'2016-09-14 07:35:53','2016-11-05 14:41:45');
/*!40000 ALTER TABLE `employees` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `migration` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES ('2014_10_12_000000_create_users_table',1),('2014_10_12_100000_create_password_resets_table',1),('2016_06_07_121600_create_employee',1),('2016_06_12_064711_create_career_table',1),('2016_06_13_101442_cretae_provider_table',1),('2016_06_16_075212_create_order_table',1),('2016_07_02_071655_orderdetailsTable',1),('2016_06_13_194645_create_product_table',2),('2016_06_14_081636_create_category_table',2),('2016_06_13_071228_cretae_customer_table',3);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `numberbuy`
--

DROP TABLE IF EXISTS `numberbuy`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `numberbuy` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `numberbuy`
--

LOCK TABLES `numberbuy` WRITE;
/*!40000 ALTER TABLE `numberbuy` DISABLE KEYS */;
INSERT INTO `numberbuy` VALUES (1,77),(2,78);
/*!40000 ALTER TABLE `numberbuy` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `numberrebuy`
--

DROP TABLE IF EXISTS `numberrebuy`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `numberrebuy` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `numberrebuy`
--

LOCK TABLES `numberrebuy` WRITE;
/*!40000 ALTER TABLE `numberrebuy` DISABLE KEYS */;
/*!40000 ALTER TABLE `numberrebuy` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `numberresell`
--

DROP TABLE IF EXISTS `numberresell`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `numberresell` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `numberresell`
--

LOCK TABLES `numberresell` WRITE;
/*!40000 ALTER TABLE `numberresell` DISABLE KEYS */;
INSERT INTO `numberresell` VALUES (1,335);
/*!40000 ALTER TABLE `numberresell` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `numbersandin`
--

DROP TABLE IF EXISTS `numbersandin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `numbersandin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `numbersandin`
--

LOCK TABLES `numbersandin` WRITE;
/*!40000 ALTER TABLE `numbersandin` DISABLE KEYS */;
INSERT INTO `numbersandin` VALUES (1,276),(2,277),(3,347),(4,348),(5,349),(6,352);
/*!40000 ALTER TABLE `numbersandin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `numbersandout`
--

DROP TABLE IF EXISTS `numbersandout`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `numbersandout` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=52 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `numbersandout`
--

LOCK TABLES `numbersandout` WRITE;
/*!40000 ALTER TABLE `numbersandout` DISABLE KEYS */;
INSERT INTO `numbersandout` VALUES (1,80),(2,278),(3,279),(4,280),(5,281),(6,282),(7,283),(8,284),(9,285),(10,286),(11,287),(12,288),(13,289),(14,290),(15,291),(16,292),(17,293),(18,294),(19,295),(20,296),(21,297),(22,298),(23,299),(24,300),(25,301),(26,302),(27,303),(28,304),(29,305),(30,306),(31,307),(32,308),(33,309),(34,310),(35,311),(36,312),(37,313),(38,314),(39,315),(40,316),(41,317),(42,318),(43,319),(44,325),(45,338),(46,343),(47,344),(48,345),(49,346),(50,350),(51,351);
/*!40000 ALTER TABLE `numbersandout` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `numbersell`
--

DROP TABLE IF EXISTS `numbersell`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `numbersell` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=223 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `numbersell`
--

LOCK TABLES `numbersell` WRITE;
/*!40000 ALTER TABLE `numbersell` DISABLE KEYS */;
INSERT INTO `numbersell` VALUES (2,69),(3,71),(4,71),(5,71),(6,73),(7,75),(8,76),(9,81),(10,82),(11,83),(12,84),(13,85),(14,86),(15,87),(16,88),(17,89),(18,90),(19,91),(20,92),(21,93),(22,94),(23,95),(24,96),(25,97),(26,98),(27,99),(28,100),(29,101),(30,102),(31,103),(32,104),(33,105),(34,106),(35,107),(36,108),(37,109),(38,110),(39,111),(40,112),(41,113),(42,114),(43,115),(44,116),(45,117),(46,118),(47,119),(48,120),(49,121),(50,122),(51,123),(52,124),(53,125),(54,126),(55,127),(56,128),(57,129),(58,130),(59,131),(60,132),(61,133),(62,134),(63,135),(64,136),(65,137),(66,138),(67,139),(68,140),(69,141),(70,142),(71,143),(72,144),(73,145),(74,146),(75,147),(76,148),(77,149),(78,150),(79,151),(80,152),(81,153),(82,154),(83,155),(84,156),(85,157),(86,158),(87,159),(88,160),(89,161),(90,162),(91,163),(92,164),(93,165),(94,166),(95,167),(96,168),(97,169),(98,170),(99,171),(100,172),(101,173),(102,174),(103,175),(104,176),(105,177),(106,178),(107,179),(108,180),(109,181),(110,182),(111,183),(112,184),(113,185),(114,186),(115,187),(116,188),(117,189),(118,190),(119,191),(120,192),(121,193),(122,194),(123,195),(124,196),(125,197),(126,198),(127,199),(128,200),(129,201),(130,202),(131,203),(132,204),(133,205),(134,206),(135,207),(136,208),(137,209),(138,210),(139,211),(140,212),(141,213),(142,214),(143,215),(144,216),(145,217),(146,218),(147,219),(148,220),(149,221),(150,222),(151,223),(152,224),(153,225),(154,226),(155,227),(156,228),(157,229),(158,230),(159,231),(160,232),(161,233),(162,234),(163,235),(164,236),(165,237),(166,238),(167,239),(168,240),(169,241),(170,242),(171,243),(172,244),(173,245),(174,246),(175,247),(176,248),(177,249),(178,250),(179,251),(180,252),(181,253),(182,254),(183,255),(184,256),(185,257),(186,258),(187,259),(188,260),(189,261),(190,262),(191,263),(192,264),(193,265),(194,266),(195,267),(196,268),(197,269),(198,270),(199,271),(200,272),(201,273),(202,274),(203,320),(204,321),(208,326),(209,327),(210,328),(211,329),(212,330),(213,331),(214,332),(215,333),(216,334),(217,336),(218,337),(219,339),(220,340),(221,341),(222,342);
/*!40000 ALTER TABLE `numbersell` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `opens`
--

DROP TABLE IF EXISTS `opens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `opens` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cash` double NOT NULL,
  `bank` double NOT NULL,
  `firstGoods` double NOT NULL,
  `lastGoods` double NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `opens`
--

LOCK TABLES `opens` WRITE;
/*!40000 ALTER TABLE `opens` DISABLE KEYS */;
INSERT INTO `opens` VALUES (1,50000,500000,10000,3000);
/*!40000 ALTER TABLE `opens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `orderdetails`
--

DROP TABLE IF EXISTS `orderdetails`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `orderdetails` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `order_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `productOrderPrice` int(11) NOT NULL,
  `productOrderQuantity` int(11) NOT NULL,
  `productOrderDis` int(11) NOT NULL,
  `productOrderAllPrice` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=354 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orderdetails`
--

LOCK TABLES `orderdetails` WRITE;
/*!40000 ALTER TABLE `orderdetails` DISABLE KEYS */;
INSERT INTO `orderdetails` VALUES (1,1,1,100,12,7,1200,NULL,NULL),(2,2,1,100,4,4,384,NULL,NULL),(3,2,2,780,3,0,2340,NULL,NULL),(4,5,1,100,400,0,40000,NULL,NULL),(5,8,2,780,6,0,4680,NULL,NULL),(6,9,2,780,3,0,2340,NULL,NULL),(7,10,1,100,33,0,3300,NULL,NULL),(8,11,2,780,44,0,34320,NULL,NULL),(9,12,1,100,9,9,819,NULL,NULL),(10,69,1,100,4,0,400,NULL,NULL),(11,69,2,780,5,0,3900,NULL,NULL),(12,71,1,100,4,0,400,NULL,NULL),(13,71,2,780,4,0,3120,NULL,NULL),(14,71,3,3232,5,0,16160,NULL,NULL),(15,73,1,100,5,0,500,NULL,NULL),(16,73,2,780,5,0,3900,NULL,NULL),(17,73,4,12121,5,0,60605,NULL,NULL),(18,75,0,0,0,0,0,NULL,NULL),(19,76,1,100,4,0,400,NULL,NULL),(20,76,2,780,4,0,3120,NULL,NULL),(21,77,0,0,0,0,0,NULL,NULL),(22,78,0,0,0,0,0,NULL,NULL),(23,81,1,100,3,0,300,NULL,NULL),(24,81,2,780,3,0,2340,NULL,NULL),(25,82,0,0,0,0,0,NULL,NULL),(26,83,0,0,0,0,0,NULL,NULL),(27,84,1,100,4,3,388,NULL,NULL),(28,85,1,100,3,0,300,NULL,NULL),(29,86,1,100,3,0,300,NULL,NULL),(30,87,0,0,0,0,0,NULL,NULL),(31,88,0,0,0,0,0,NULL,NULL),(32,89,0,0,0,0,0,NULL,NULL),(33,90,0,0,0,0,0,NULL,NULL),(34,91,1,100,44,0,4400,NULL,NULL),(35,92,1,100,44,0,4400,NULL,NULL),(36,93,1,100,44,0,4400,NULL,NULL),(37,94,1,100,4,0,400,NULL,NULL),(38,95,4,12121,4,0,48484,NULL,NULL),(39,96,2,780,7,6,5132,NULL,NULL),(40,97,2,780,7,6,5132,NULL,NULL),(41,98,2,780,5,0,3900,NULL,NULL),(42,99,2,780,5,4,3744,NULL,NULL),(43,100,1,100,4,3,388,NULL,NULL),(44,101,1,100,8,0,800,NULL,NULL),(45,102,1,100,5,0,500,NULL,NULL),(46,102,3,3232,5,0,16160,NULL,NULL),(47,103,1,100,6,0,600,NULL,NULL),(48,104,0,0,0,0,0,NULL,NULL),(49,105,0,0,0,0,0,NULL,NULL),(50,106,0,0,0,0,0,NULL,NULL),(51,107,1,100,5,33,335,NULL,NULL),(52,108,2,780,5,55,1755,NULL,NULL),(53,109,1,100,512,12,45056,NULL,NULL),(54,110,1,100,5,11,445,NULL,NULL),(55,110,2,780,4,10,2808,NULL,NULL),(56,110,4,12121,4,12,42666,NULL,NULL),(57,111,1,100,5,0,500,NULL,NULL),(58,111,0,0,0,0,0,NULL,NULL),(59,112,1,100,3,12,264,NULL,NULL),(60,112,2,780,0,0,0,NULL,NULL),(61,113,2,780,4,12,2746,NULL,NULL),(62,113,0,0,0,0,0,NULL,NULL),(63,114,2,780,4,12,2746,NULL,NULL),(64,115,1,100,4,10,360,NULL,NULL),(65,115,2,780,4,12,2746,NULL,NULL),(66,116,1,100,5,4,480,NULL,NULL),(67,116,3,3232,4,0,12928,NULL,NULL),(68,116,0,0,0,0,0,NULL,NULL),(69,116,0,0,0,0,0,NULL,NULL),(70,116,0,0,0,0,0,NULL,NULL),(71,116,0,0,0,0,0,NULL,NULL),(72,116,0,0,0,0,0,NULL,NULL),(73,116,0,0,0,0,0,NULL,NULL),(74,116,0,0,0,0,0,NULL,NULL),(75,116,0,0,0,0,0,NULL,NULL),(76,117,2,780,4,4,2995,NULL,NULL),(77,117,1,100,4,0,400,NULL,NULL),(78,118,1,100,3,3,291,NULL,NULL),(79,118,2,780,2,3,1513,NULL,NULL),(80,118,3,3232,3,0,9696,NULL,NULL),(81,118,0,0,0,0,0,NULL,NULL),(82,119,1,100,5,12,440,NULL,NULL),(83,119,2,780,5,0,3900,NULL,NULL),(84,119,0,0,0,0,0,NULL,NULL),(85,119,0,0,0,0,0,NULL,NULL),(86,120,1,100,5,1,495,NULL,NULL),(87,120,3,3232,3,12,8532,NULL,NULL),(88,121,2,780,5,0,3900,NULL,NULL),(89,121,3,3232,4,12,11377,NULL,NULL),(90,122,1,100,5,12,440,NULL,NULL),(91,122,2,780,0,0,0,NULL,NULL),(92,123,1,100,5,12,440,NULL,NULL),(93,123,0,0,0,0,0,NULL,NULL),(94,124,1,100,4,12,352,NULL,NULL),(95,124,2,780,5,12,3432,NULL,NULL),(96,125,2,780,4,1,3089,NULL,NULL),(97,125,0,0,0,12,0,NULL,NULL),(98,126,3,3232,4,0,12928,NULL,NULL),(99,126,5,2121,31,12,57861,NULL,NULL),(100,127,1,100,4,1,396,NULL,NULL),(101,127,1,100,4,12,352,NULL,NULL),(102,128,0,0,0,0,0,NULL,NULL),(103,129,0,0,0,0,0,NULL,NULL),(104,130,0,0,0,0,0,NULL,NULL),(105,131,2,780,4,12,2746,NULL,NULL),(106,132,1,100,5,12,440,NULL,NULL),(107,133,2,780,4,12,2746,NULL,NULL),(108,134,1,100,5,12,440,NULL,NULL),(109,135,1,100,7,12,616,NULL,NULL),(110,136,1,100,31,12,2728,NULL,NULL),(111,137,1,100,31,12,2728,NULL,NULL),(112,138,1,100,4,12,352,NULL,NULL),(113,139,1,100,4,12,352,NULL,NULL),(114,140,1,100,3,12,264,NULL,NULL),(115,141,1,100,5,0,500,NULL,NULL),(116,141,2,780,3,12,2059,NULL,NULL),(117,142,2,780,4,0,3120,NULL,NULL),(118,143,0,0,0,0,0,NULL,NULL),(119,144,2,780,5,0,3900,NULL,NULL),(120,145,1,100,3,12,264,NULL,NULL),(121,146,0,0,0,0,0,NULL,NULL),(122,147,1,100,4,4,384,NULL,NULL),(123,147,3,3232,4,12,11377,NULL,NULL),(124,148,0,0,0,0,0,NULL,NULL),(125,149,0,0,0,0,0,NULL,NULL),(126,150,1,100,5,12,440,NULL,NULL),(127,151,1,100,5,12,440,NULL,NULL),(128,152,1,100,52,2,5096,NULL,NULL),(129,153,2,780,7,7,5078,NULL,NULL),(130,154,2,780,7,7,5078,NULL,NULL),(131,155,2,780,7,7,5078,NULL,NULL),(132,156,2,780,7,7,5078,NULL,NULL),(133,157,2,780,7,7,5078,NULL,NULL),(134,158,2,780,7,7,5078,NULL,NULL),(135,159,1,100,5,4,480,NULL,NULL),(136,160,2,780,4,4,2995,NULL,NULL),(137,161,2,780,6,4,4493,NULL,NULL),(138,162,2,780,6,4,4493,NULL,NULL),(139,163,2,780,6,4,4493,NULL,NULL),(140,164,2,780,8,2,6115,NULL,NULL),(141,165,2,780,8,2,6115,NULL,NULL),(142,165,2,780,7,3,5296,NULL,NULL),(143,165,1,100,66,6,6204,NULL,NULL),(144,165,0,0,0,0,0,NULL,NULL),(145,166,1,100,5,5,475,NULL,NULL),(146,166,2,780,6,3,4540,NULL,NULL),(147,167,1,100,5,5,475,NULL,NULL),(148,167,2,780,6,3,4540,NULL,NULL),(149,168,1,100,5,4,480,NULL,NULL),(150,168,2,780,5,2,3822,NULL,NULL),(151,169,2,780,5,5,3705,NULL,NULL),(152,169,2,780,6,4,4493,NULL,NULL),(153,170,1,100,5,5,475,NULL,NULL),(154,171,1,100,4,5,380,NULL,NULL),(155,172,3,3232,5,5,15352,NULL,NULL),(156,176,1,100,8,9,800,NULL,NULL),(157,176,2,780,9,11,7020,NULL,NULL),(158,177,1,100,1,1,100,NULL,NULL),(159,177,2,780,1,9,780,NULL,NULL),(160,178,1,100,5,11,445,NULL,NULL),(161,178,2,780,1,1,772,NULL,NULL),(162,178,1,100,1,7,93,NULL,NULL),(163,182,3,3232,44,0,142208,NULL,NULL),(164,182,1,100,55,0,5500,NULL,NULL),(165,183,1,100,5,0,500,NULL,NULL),(166,184,1,100,5,0,500,NULL,NULL),(167,185,2,780,5,0,3900,NULL,NULL),(168,185,1,100,4,0,400,NULL,NULL),(169,185,3,3232,3,0,9696,NULL,NULL),(170,186,2,780,5,0,3900,NULL,NULL),(171,186,1,100,4,0,400,NULL,NULL),(172,186,3,3232,3,0,9696,NULL,NULL),(173,187,2,780,5,0,3900,NULL,NULL),(174,187,1,100,4,0,400,NULL,NULL),(175,187,3,3232,3,0,9696,NULL,NULL),(176,188,2,780,5,0,3900,NULL,NULL),(177,188,1,100,4,0,400,NULL,NULL),(178,188,3,3232,3,0,9696,NULL,NULL),(179,189,1,100,1,0,100,NULL,NULL),(180,189,2,780,1,0,780,NULL,NULL),(181,190,1,100,1,0,100,NULL,NULL),(182,190,2,780,1,0,780,NULL,NULL),(183,191,1,100,1,0,100,NULL,NULL),(184,191,2,780,1,0,780,NULL,NULL),(185,192,1,100,1,0,100,NULL,NULL),(186,192,2,780,1,0,780,NULL,NULL),(187,193,2,780,5,0,3900,NULL,NULL),(188,193,1,100,6,0,600,NULL,NULL),(189,194,2,780,5,0,3900,NULL,NULL),(190,194,1,100,6,0,600,NULL,NULL),(191,195,1,100,4,0,400,NULL,NULL),(192,195,2,780,2,0,1560,NULL,NULL),(193,196,1,100,4,0,400,NULL,NULL),(194,196,2,780,5,0,3900,NULL,NULL),(195,197,1,100,4,0,400,NULL,NULL),(196,197,2,780,5,0,3900,NULL,NULL),(197,198,1,100,4,0,400,NULL,NULL),(198,198,2,780,5,0,3900,NULL,NULL),(199,199,1,100,9,0,900,NULL,NULL),(200,199,2,780,4,0,3120,NULL,NULL),(201,200,1,100,9,0,900,NULL,NULL),(202,200,2,780,4,0,3120,NULL,NULL),(203,201,1,100,1,0,100,NULL,NULL),(204,201,2,780,1,0,780,NULL,NULL),(205,202,1,100,1,0,100,NULL,NULL),(206,202,2,780,1,0,780,NULL,NULL),(207,203,1,100,2,0,200,NULL,NULL),(208,203,2,780,2,0,1560,NULL,NULL),(209,204,1,100,2,0,200,NULL,NULL),(210,204,2,780,2,0,1560,NULL,NULL),(211,205,1,100,2,0,200,NULL,NULL),(212,205,2,780,2,0,1560,NULL,NULL),(213,206,1,100,2,0,200,NULL,NULL),(214,206,2,780,2,0,1560,NULL,NULL),(215,207,1,100,2,0,200,NULL,NULL),(216,207,2,780,2,0,1560,NULL,NULL),(217,208,1,100,2,0,200,NULL,NULL),(218,209,1,100,1,0,100,NULL,NULL),(219,210,1,100,1,0,100,NULL,NULL),(220,211,1,100,1,0,100,NULL,NULL),(221,212,1,100,1,0,100,NULL,NULL),(222,213,2,780,8,0,6240,NULL,NULL),(223,214,2,780,8,0,6240,NULL,NULL),(224,215,2,780,8,0,6240,NULL,NULL),(225,216,2,780,8,0,6240,NULL,NULL),(226,216,1,100,9,0,900,NULL,NULL),(227,217,2,780,8,0,6240,NULL,NULL),(228,217,1,100,9,0,900,NULL,NULL),(229,218,2,780,8,0,6240,NULL,NULL),(230,218,1,100,9,0,900,NULL,NULL),(231,219,2,780,8,0,6240,NULL,NULL),(232,219,1,100,9,0,900,NULL,NULL),(233,220,2,780,8,0,6240,NULL,NULL),(234,220,1,100,9,0,900,NULL,NULL),(235,221,2,780,8,0,6240,NULL,NULL),(236,221,1,100,9,0,900,NULL,NULL),(237,222,2,780,8,0,6240,NULL,NULL),(238,222,1,100,9,0,900,NULL,NULL),(239,223,2,780,8,0,6240,NULL,NULL),(240,223,1,100,9,0,900,NULL,NULL),(241,224,1,100,2,0,200,NULL,NULL),(242,224,2,780,2,0,1560,NULL,NULL),(243,225,1,100,2,0,200,NULL,NULL),(244,225,2,780,2,0,1560,NULL,NULL),(245,226,1,100,2,0,200,NULL,NULL),(246,226,2,780,2,0,1560,NULL,NULL),(247,227,1,100,2,0,200,NULL,NULL),(248,227,2,780,2,0,1560,NULL,NULL),(249,228,1,100,2,0,200,NULL,NULL),(250,228,2,780,2,0,1560,NULL,NULL),(251,229,1,100,2,0,200,NULL,NULL),(252,230,1,100,9,0,900,NULL,NULL),(253,230,2,780,9,0,7020,NULL,NULL),(254,231,1,100,9,0,900,NULL,NULL),(255,231,2,780,6,0,4680,NULL,NULL),(256,232,1,100,8,0,800,NULL,NULL),(257,232,2,780,9,0,7020,NULL,NULL),(258,233,1,100,8,0,800,NULL,NULL),(259,233,2,780,9,0,7020,NULL,NULL),(260,234,1,100,8,0,800,NULL,NULL),(261,234,2,780,9,0,7020,NULL,NULL),(262,235,1,100,8,0,800,NULL,NULL),(263,235,2,780,9,0,7020,NULL,NULL),(264,236,1,100,8,0,800,NULL,NULL),(265,236,2,780,9,0,7020,NULL,NULL),(266,237,1,100,8,0,800,NULL,NULL),(267,237,2,780,9,0,7020,NULL,NULL),(268,238,1,100,8,0,800,NULL,NULL),(269,238,2,780,9,0,7020,NULL,NULL),(270,239,1,100,8,0,800,NULL,NULL),(271,239,2,780,9,0,7020,NULL,NULL),(272,240,1,100,8,0,800,NULL,NULL),(273,240,2,780,9,0,7020,NULL,NULL),(274,241,1,100,8,0,800,NULL,NULL),(275,242,1,100,8,0,800,NULL,NULL),(276,243,1,100,8,0,800,NULL,NULL),(277,244,1,100,8,0,800,NULL,NULL),(278,245,1,100,8,0,800,NULL,NULL),(279,246,1,100,8,0,800,NULL,NULL),(280,247,1,100,1,0,100,NULL,NULL),(281,247,2,780,2,0,1560,NULL,NULL),(282,248,1,100,1,0,100,NULL,NULL),(283,248,2,780,2,0,1560,NULL,NULL),(284,248,3,3232,3,0,9696,NULL,NULL),(285,249,2,780,3,0,2340,NULL,NULL),(286,249,1,100,4,0,400,NULL,NULL),(287,250,1,100,4,0,400,NULL,NULL),(288,250,2,780,5,0,3900,NULL,NULL),(289,251,1,100,3,0,300,NULL,NULL),(290,251,2,780,3,0,2340,NULL,NULL),(291,251,3,3232,4,0,12928,NULL,NULL),(292,252,1,100,1,0,100,NULL,NULL),(293,252,2,780,3,0,2340,NULL,NULL),(294,253,1,100,2,0,200,NULL,NULL),(295,253,2,780,4,0,3120,NULL,NULL),(296,253,3,3232,4,0,12928,NULL,NULL),(297,254,1,100,4,0,400,NULL,NULL),(298,254,3,3232,4,0,12928,NULL,NULL),(299,258,1,100,8,0,800,NULL,NULL),(300,260,1,100,5,0,500,NULL,NULL),(301,260,2,780,4,0,3120,NULL,NULL),(302,261,1,100,3,0,300,NULL,NULL),(303,261,3,3232,3,0,9696,NULL,NULL),(304,262,1,100,3,0,300,NULL,NULL),(305,262,3,3232,2,0,6464,NULL,NULL),(306,263,3,3232,1,0,3232,NULL,NULL),(307,264,3,3232,1,0,3232,NULL,NULL),(308,265,3,3232,8,0,25856,NULL,NULL),(309,266,3,3232,10,0,32320,NULL,NULL),(310,267,1,100,8,0,800,NULL,NULL),(311,267,3,3232,99,0,319968,NULL,NULL),(312,269,1,100,50,0,5000,NULL,NULL),(313,270,1,100,50,0,5000,NULL,NULL),(314,270,3,3232,50,0,32320,NULL,NULL),(315,271,1,100,7,0,700,NULL,NULL),(316,272,1,100,36,0,700,NULL,NULL),(317,272,3,3232,36,0,32320,NULL,NULL),(318,273,1,100,80,0,1000,NULL,NULL),(319,273,2,780,80,0,15600,NULL,NULL),(320,273,3,3232,80,0,290880,NULL,NULL),(321,274,1,100,5,0,500,NULL,NULL),(322,274,2,780,6,6,4399,NULL,NULL),(323,274,4,12121,5,1,59999,NULL,NULL),(324,274,5,2121,5,0,10605,NULL,NULL),(325,274,6,2121,5,10,9545,NULL,NULL),(326,274,5,2121,5,0,10605,NULL,NULL),(327,274,4,12121,3,0,36363,NULL,NULL),(328,274,4,12121,2,11,21575,NULL,NULL),(329,320,1,100,4,6,376,NULL,NULL),(330,320,3,3232,4,3,12540,NULL,NULL),(331,321,1,100,4,6,376,NULL,NULL),(332,321,3,3232,4,3,12540,NULL,NULL),(333,326,2,780,8,0,6240,NULL,NULL),(334,327,1,100,8,0,800,NULL,NULL),(335,328,1,100,5,0,500,NULL,NULL),(336,329,1,100,4,0,400,NULL,NULL),(337,330,1,100,44,0,4400,NULL,NULL),(338,331,1,100,7,12,616,NULL,NULL),(339,332,1,100,111,0,11100,NULL,NULL),(340,333,1,100,1111,0,111100,NULL,NULL),(341,334,2,780,10,0,7800,NULL,NULL),(342,335,1,100,22,0,2200,NULL,NULL),(343,335,2,780,22,0,17160,NULL,NULL),(344,335,3,3232,22,0,71104,NULL,NULL),(345,336,1,100,100,0,10000,NULL,NULL),(346,336,2,780,100,0,78000,NULL,NULL),(347,337,1,100,111,0,11100,NULL,NULL),(348,337,2,780,111,0,86580,NULL,NULL),(349,339,1,100,44,12,3872,NULL,NULL),(350,339,3,3232,55,10,159984,NULL,NULL),(351,340,1,100,3,10,270,NULL,NULL),(352,341,1,100,4,0,400,NULL,NULL),(353,342,3,3232,9,0,29088,NULL,NULL);
/*!40000 ALTER TABLE `orderdetails` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `orders`
--

DROP TABLE IF EXISTS `orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `orders` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `orderType` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `orderDate` date NOT NULL,
  `orderPaymentType` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `orderBankName` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `employee_id` int(11) NOT NULL,
  `fromto` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `orderCheckNO` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `orderDueDate` date NOT NULL,
  `car_id` int(11) NOT NULL,
  `employeeName` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
  `customer_id` int(11) NOT NULL,
  `kilo` double NOT NULL,
  `provider_id` int(11) NOT NULL,
  `getMoney` double NOT NULL,
  `backMoney` double NOT NULL,
  `orderPayment` double NOT NULL,
  `orderOutPayment` double NOT NULL,
  `orderNote` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `month` varchar(3) COLLATE utf8_unicode_ci NOT NULL,
  `numberbill` int(10) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=353 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orders`
--

LOCK TABLES `orders` WRITE;
/*!40000 ALTER TABLE `orders` DISABLE KEYS */;
INSERT INTO `orders` VALUES (331,'sell','2016-10-28','cash','',0,'','','2016-10-28',0,'مازن خالد بديوي',3,0,0,0,616,616,0,'','10',0,NULL,NULL),(332,'sell','2016-10-30','cash','',0,'','','2016-10-30',0,'مازن خالد بديوي',2,0,0,1111,96569,97680,0,'','10',0,NULL,NULL),(333,'sell','2016-10-30','cash','',0,'','','2016-10-30',0,'مازن خالد بديوي',2,0,0,1111,4567321,4568432,0,'','8',0,NULL,NULL),(334,'sell','2016-10-30','cash','',0,'','','2016-10-30',0,'مازن خالد بديوي',3,0,0,444,71828860,71829304,0,'','9',0,NULL,NULL),(335,'resell','0000-00-00','اختر','',0,'','','0000-00-00',2,'',3,0,0,0,0,0,0,'','9',0,NULL,NULL),(336,'sell','2016-10-30','cash','',0,'','','2016-10-30',0,'مازن خالد بديوي',2,0,0,9000,79000,88000,0,'','10',0,NULL,NULL),(337,'sell','2016-10-30','cash','',0,'','','2016-10-30',0,'مازن خالد بديوي',2,0,0,1111,96569,97680,0,'','10',0,NULL,NULL),(338,'sandout','2016-11-06','cash','',0,'','','0000-00-00',0,'',0,0,4,0,0,0,4444,'','',0,NULL,NULL),(339,'sell','2016-11-06','cash','',0,'','','2016-11-06',0,'ربيع سيو',0,0,0,16000,147856,163856,0,'','11',0,NULL,NULL),(340,'sell','2016-11-06','cash','',0,'','','2016-11-06',0,'ربيع سيو',2,0,0,200,70,270,0,'','11',0,NULL,NULL),(341,'sell','2016-11-11','cash','',0,'','','2016-11-11',2,'ربيع سيو',2,3455,0,40,360,400,0,'','11',0,NULL,NULL),(342,'sell','2016-11-11','cash','',0,'','','2016-11-11',0,'مازن بديوي',2,0,0,7000,22088,29088,0,'','11',0,NULL,NULL),(343,'sandout','2016-11-18','cash','',2,'','','0000-00-00',0,'',0,0,0,0,0,0,6000,'','',0,NULL,NULL),(344,'sandout','2016-11-18','cash','',3,'salary','','0000-00-00',0,'',0,0,0,0,0,0,9000,'','',0,NULL,NULL),(345,'sandout','2016-11-18','cash','',2,'rentSalary','','0000-00-00',0,'ربيع سيو',0,0,0,0,0,0,444,'','',0,NULL,NULL),(346,'sandout','2016-11-18','cash','',0,'water','','0000-00-00',0,'ربيع سيو',0,0,1,0,0,0,444,'','',0,NULL,NULL),(347,'sandin','2016-11-19','cash','',0,'','','0000-00-00',0,'ربيع سيو',2,0,0,40000,0,0,0,'','',0,NULL,NULL),(348,'sandin','2016-11-19','cash','',0,'','','0000-00-00',0,'ربيع سيو',2,0,0,4000000,0,0,0,'','',0,NULL,NULL),(349,'sandin','2016-11-19','cash','',0,'','','0000-00-00',0,'ربيع سيو',2,0,0,800000,0,0,0,'','',0,NULL,NULL),(350,'sandout','2016-11-19','cash','',2,'salary','','0000-00-00',0,'ربيع سيو',0,0,0,0,0,0,40000,'','',0,NULL,NULL),(351,'sandout','2016-11-19','cash','',2,'fromhome','','0000-00-00',0,'ربيع سيو',0,0,0,0,0,0,3000,'','',0,NULL,NULL),(352,'sandin','2016-11-24','cash','',0,'غفش بيت للزلمة','','0000-00-00',0,'ربيع سيو',2,0,0,5000,0,0,0,'','',0,NULL,NULL);
/*!40000 ALTER TABLE `orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_resets`
--

DROP TABLE IF EXISTS `password_resets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  KEY `password_resets_email_index` (`email`),
  KEY `password_resets_token_index` (`token`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_resets`
--

LOCK TABLES `password_resets` WRITE;
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `products`
--

DROP TABLE IF EXISTS `products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `products` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `productCode` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `productName` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `productDescription` text COLLATE utf8_unicode_ci NOT NULL,
  `productNetPrice` double NOT NULL,
  `productQuntity` int(11) NOT NULL,
  `allQuantity` double NOT NULL,
  `productUnit` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `productSellPrice` double NOT NULL,
  `productTotalPrice` double NOT NULL,
  `category_id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `products`
--

LOCK TABLES `products` WRITE;
/*!40000 ALTER TABLE `products` DISABLE KEYS */;
INSERT INTO `products` VALUES (1,'22211','oil','',100,-89,99560,'',0,0,1,0,'2016-08-13 19:13:24','2016-09-17 08:18:32'),(2,'111','zahra','',780,-33,2000000,'',0,0,1,0,'2016-08-13 19:13:49','2016-08-13 19:13:49'),(3,'323232','هميرغر','ثصثص',3232,14,15000,'32',0,30000,1,0,'2016-09-04 05:42:35','2016-09-04 05:42:35'),(4,'34343','rerere','qwqw',12121,39995,150000,'2121',0,2121,1,0,'2016-09-04 05:44:12','2016-09-04 05:44:12'),(5,'3232','bbb','2121',2121,9995,12000,'3232',0,2121,1,0,'2016-09-04 05:44:35','2016-09-04 05:44:35'),(6,'3232','2121','2121',2121,2101,2500,'212',0,2121,1,0,'2016-09-04 05:44:51','2016-09-04 05:44:51'),(26,'jhkhkh','hkhj','khkh',0,0,0,'hkhkh',0,0,1,0,'2016-11-18 21:12:35','2016-11-18 21:12:35'),(27,'nkhkh','hkhkh','khkh',0,0,0,'khkhk',0,0,1,0,'2016-11-18 21:12:48','2016-11-18 21:12:48'),(28,'ljljlj','ljljlj','ljljl',0,0,0,'ljljlj',0,0,1,0,'2016-11-18 21:13:01','2016-11-18 21:13:01'),(29,'ljljlj','ljljlj','lkjljlkj',0,0,0,'lkjklj',0,0,1,0,'2016-11-18 21:13:15','2016-11-18 21:13:15'),(30,'hjkhkh','khkhkh','khkh',0,0,0,'hhhhhkjh',0,0,1,0,'2016-11-18 21:13:28','2016-11-18 21:13:28'),(31,'jkjkj','jkj','kjkjkj',0,0,0,'kjkj',0,0,1,0,'2016-11-19 17:53:29','2016-11-19 17:53:29'),(32,'lk;klkl','lklk','lklklk',0,0,0,'lklkl',0,0,1,0,'2016-11-19 17:53:44','2016-11-19 17:53:44'),(33,'jkjkj','kjkjk','jkjkj',0,0,0,'jkjk',0,0,1,0,'2016-11-19 17:53:57','2016-11-19 17:53:57'),(34,'kjkjk','jkjk','jkjkj',0,0,0,'jkjkj',0,0,1,0,'2016-11-19 17:54:09','2016-11-19 17:54:09');
/*!40000 ALTER TABLE `products` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `providers`
--

DROP TABLE IF EXISTS `providers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `providers` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `providerFirstName` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `providerMiddleName` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `providerLastName` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `providerCompany` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `providerMobile` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `providerPhoneJob` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `providerPhoneHome` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `providerAddress` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `providerCity` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `providerNational` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `providerCreditor` double NOT NULL,
  `providerPaymentDate` date NOT NULL,
  `providerDebt` double NOT NULL,
  `limit` double NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `providers`
--

LOCK TABLES `providers` WRITE;
/*!40000 ALTER TABLE `providers` DISABLE KEYS */;
INSERT INTO `providers` VALUES (1,'عبد الرحمن','زكريا','المحمد','','43434343','434343','4344343','دمشق ابو رمانة','دمشق','سوري',0,'0000-00-00',0,0,'2016-08-19 20:54:38','2016-11-06 15:47:37'),(4,'سمير ','سميح','الطويل ','','3232323','323232','323232','سينتر ستي ','بيروت','لبناني',0,'0000-00-00',0,0,'2016-10-13 04:18:57','2016-11-06 15:48:25'),(5,'wwww','wwwww','wwww','','wwww','wwww','wwww','wwww','wwww','wwww',0,'0000-00-00',0,0,'2016-11-10 05:33:24','2016-11-10 05:33:24'),(6,'11111111111','1111','1111','','11111','11111','1111','11111','11111','11111',0,'0000-00-00',0,0,'2016-11-10 07:30:29','2016-11-10 07:30:29');
/*!40000 ALTER TABLE `providers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `userDisc` int(11) NOT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `admin` tinyint(4) NOT NULL,
  `remember_token` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'ربيع سيو','rabih@oil.com',12,'$2y$10$2c4Ej0bsB5o0SWrY0xK4oerxdjk9/oMDr7fBWDbKTf7R/ZHKYtkNu',1,'z8W9xDIkDU8TNLHm9uRbaq9hbfpRsItfGp3bHPcHHWjKbxnuOrU2iFhonFQM','2016-08-13 18:14:11','2016-11-14 18:03:13'),(2,'حازم شيخاني','hazem@oil.com',20,'$2y$10$nI7oEE7e1fpuqAdZIxZw2ezeNEFil6vRncC1ieb.ehZUZGgHhRt16',3,'yegoyu8D9iv4zguhJhWmBykYTCH3cIWxVOg4X47oUHZWl2V36WdNB4RhXo4H','2016-09-14 12:23:35','2016-11-14 19:23:18'),(3,'test7','test@test.mmm8',0,'$2y$10$uEKNcW0KwnCzQokGfTQVvOzDDLGymSCfk245MkQpq0BELJcr3IL0a',1,'eSpVdAkEJvCzKJ5e6E3uAl67a9BoNwlTtdWSfrnL7nzn1n3sRI0ePlDjrNXp','2016-09-15 12:06:35','2016-09-16 17:36:37'),(4,'مازن بديوي','mazen@oil.com',20,'$2y$10$S1ShJh/wh75dHyckR0RJ7eBZNz4v50WIV..gsVY65VE2NFAHN5m9S',2,'totKLv36P0VuybEHj7y1RL8vAsQ8aFzkfLdhma1CvGTeKUWlhwwFz4HOYGeI','2016-09-15 17:44:41','2016-11-19 16:58:48'),(5,'حسن اسمر','hasan@oil.com',0,'$2y$10$9X93s3/5IwGAuo3VlvbsZ.5MEYNXqz4Qe6JtSnBomf481zrj0D2WG',0,NULL,'2016-09-24 15:50:02','2016-11-05 16:31:35'),(6,'test','test@4.n',0,'$2y$10$ZCLDo7iLCJn20TSjh8m7kOioRHdTWOLCgHM1jphnXfbOEzgw7bgbK',0,NULL,'2016-09-24 16:01:34','2016-09-24 16:01:34');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-11-24 22:25:35
